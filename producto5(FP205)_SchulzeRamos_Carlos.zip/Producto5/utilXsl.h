#ifndef UTIL_XSL_H
#define UTIL_XSL_H

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

void flujo_crear_xsl(const char* xml_path, const char* xsl_path);

#endif