#ifndef UTIL_H
#define UTIL_H

void insertar_fecha_hora(const char* ruta_archivo);

#endif