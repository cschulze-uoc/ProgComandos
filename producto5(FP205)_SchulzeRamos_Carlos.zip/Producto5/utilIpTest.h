#ifndef UTIL_IPTEST_H
#define UTIL_IPTEST_H

void testIps(const char* rutaSalida);
void imprimir_ips(const char* ruta_ips);
int probar_ip(const char* ip);
void comprobar_ips(const char* ruta_archivo_ips, const char* ruta_salida);

#endif